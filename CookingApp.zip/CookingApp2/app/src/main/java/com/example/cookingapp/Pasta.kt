package com.example.cookingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Pasta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pasta)
    }
}