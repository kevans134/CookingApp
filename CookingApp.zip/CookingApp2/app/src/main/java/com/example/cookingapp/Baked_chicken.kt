package com.example.cookingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Baked_chicken : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_baked_chicken)
    }
}